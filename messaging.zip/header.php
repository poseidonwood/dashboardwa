<?php
//-------------------------------------------------------------------------------
//
//   This notice must remain untouched at all times.
//   Copyright Alucio Net Technologies 2006. All rights reserved.
//   By Alucio Net Technologies.  Last modified 03-07-2006.
//
//   This script/code is owned and copyrighted by Alucio Net Technologies.
//   The following code cannot be duplicated, distributed, or modified
//   without prior agreements from Alucio Net Technologies. Violations to
//   this terms will be considered as criminal acts and the violators will
//   be persecuted to the maximum possible extent by the governing laws.
//
//   Author           : Junaidi Halin
//   Date created     : 06/13/06
//
//   Modifications history:
//      - 06/13/06 JHALIN Created script
//      - 11/25/06 Lenny edit for group entity
//-------------------------------------------------------------------------------
?>
<?php
require_once("configuration.inc");
require_once(ONELOGIN_ACL_CLASS);

//require_once("includes/siteGrantor.php");

//$machineSessionID=GetAndValidateSiteSessionID();
//if ($machineSessionID == -1)
//{
//    header("Location: {$error_page}");
//    // TODO: write log on problem logs
//}

$login_page = "{$login_page}?application={$site_name}".
              "&referrer=".urlencode(CONN_PROTOCOL."{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}");
$logout_page.="&referrer=".CONN_PROTOCOL.urlencode("{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}");

/*
if (!isset($_COOKIE['oneLogin']))
{
   header("location:{$login_page}");
   exit;
}
*/
require_once(COMMON_INC_DIR."class.olahDB.php");
require_once(COMMON_INC_DIR."class.configs.php");
//require_once(SYNERGIS_INC_DIR."class.activityGrantor.php");
//require_once(SYNERGIS_INC_DIR."class.SynergisUser.php");
//require_once(SYNERGIS_INC_DIR."class.Entity.php");
//require_once(COMMON_INC_DIR."general.api.php");
/*
if ($GLOBALS['ONELOGIN']['remote_messaging_protocol']=="db")
{
   require_once(ONELOGIN_INC_DIR."class.users.php");
   require_once(ONELOGIN_INC_DIR."class.sessions.php");
   require_once(ONELOGIN_INC_DIR."class.sites.php");
}
*/
// TODO: handle non db onelogin

function create_cookie()
{
   require_once(COMMON_INC_DIR."class.mdetect.php");
   global $activityGrantor,$user_session,$logout_page;

   //get user warehouse location
   $cSU=new cSynergisUser(true);
   if ($_COOKIE['onelogin_id']!="")
   {
      $cond= " user_onelogin_id= '{$_COOKIE['onelogin_id']}' ";
      $GLOBALS['current_user']['data']['userID']=$_COOKIE['onelogin_id'];
   }
   elseif ($user_session['userID']!="")
   {
      $cond= " user_onelogin_id= '{$user_session['userID']}' ";
      $GLOBALS['current_user']['data']['userID']=$user_session['userID'];
   }

   $dataSU=$cSU->get_users_list($cond);
   //kontakID taken from synergis.user_db
   $GLOBALS['current_user']['data']['username']=$dataSU[0]['username'];

   setcookie("current_user[data][userID]", $GLOBALS['current_user']['data']['userID'],time()+60*60*12,"/",SITE_DOMAIN);
   setcookie("current_user[data][username]", $GLOBALS['current_user']['data']['username'],time()+60*60*12,"/",SITE_DOMAIN);
   $_COOKIE['current_user']['data']['userID']=$GLOBALS['current_user']['data']['userID'];
   $_COOKIE['current_user']['data']['username']=$GLOBALS['current_user']['data']['username'];

   if ($dataSU[0]['user_warehouse_id']=="")
   {
      header("location:{$logout_page}");
      exit;
   }

   $GLOBALS['current_user']['data']['kontakID']=$dataSU[0]['user_kontak_id'];
   setcookie("current_user[data][kontakID]", $GLOBALS['current_user']['data']['kontakID'],time()+60*60*12,"/",SITE_DOMAIN);
   $_COOKIE['current_user']['data']['kontakID']=$dataSU[0]['user_kontak_id'];

   $GLOBALS['current_user']['data']['warehouseID']=$dataSU[0]['user_warehouse_id'];
   setcookie("current_user[data][warehouseID]", $GLOBALS['current_user']['data']['warehouseID'],time()+60*60*12,"/",SITE_DOMAIN);
   $_COOKIE['current_user']['data']['warehouseID']=$dataSU[0]['user_warehouse_id'];

   $GLOBALS['current_user']['data']['groupID']=$dataSU[0]['user_group_id'];
   setcookie("current_user[data][groupID]", $GLOBALS['current_user']['data']['groupID'],time()+60*60*12,"/",SITE_DOMAIN);
   $_COOKIE['current_user']['data']['groupID']=$dataSU[0]['user_group_id'];

   $GLOBALS['current_user']['data']['warehouseName']=$dataSU[0]['warehouse_name'];
   setcookie("current_user[data][warehouseName]", $GLOBALS['current_user']['data']['warehouseName'],time()+60*60*12,"/",SITE_DOMAIN);
   $_COOKIE['current_user']['data']['warehouseName']=$dataSU[0]['warehouse_name'];

   $cMobile=new uagent_info();
   if ($cMobile->DetectMobileQuick())
   {
      $GLOBALS['current_user']['data']['mobileAccess']="1";
      setcookie("current_user[data][mobileAccess]", "1",time()+60*60*12,"/",SITE_DOMAIN);
      $_COOKIE['current_user']['data']['mobileAccess']="1";
   }
}


$cookieValue="none";
if (isset($_COOKIE["oneLogin"]))
{
   $cookieValue=$_COOKIE["oneLogin"];
}

$siteIP=$_SERVER['SERVER_ADDR'];
if ($_SERVER['SERVER_PORT']!=80)
{
   $siteIP="{$siteIP} : {$_SERVER['SERVER_PORT']}";
}

/*
$activityGrantor=new cActivityGrantor($cookieValue,$siteIP,$_SERVER["REMOTE_ADDR"]);

if ($activityGrantor->isSessionValid()!=1)
{
   header("location:{$logout_page}");
   exit;
}
else
   $user_session = $activityGrantor->getSessionData();

//set current user ke dalam cookie
if (!isset($_COOKIE['current_user']))
{
   create_cookie();
}
else
{
   if ((isset($_COOKIE['current_user']['data']['warehouseID'])) && ($_COOKIE['current_user']['data']['warehouseID']!=""))
      $GLOBALS['current_user']['data']['warehouseID']=$_COOKIE['current_user']['data']['warehouseID'];
   else
      create_cookie();
   if (isset($_COOKIE['current_user']['data']['warehouseName']))
      $GLOBALS['current_user']['data']['warehouseName']=$_COOKIE['current_user']['data']['warehouseName'];
   if (isset($_COOKIE['current_user']['data']['kontakID']))
      $GLOBALS['current_user']['data']['kontakID']=$_COOKIE['current_user']['data']['kontakID'];
   if (isset($_COOKIE['current_user']['data']['groupID']))
      $GLOBALS['current_user']['data']['groupID']=$_COOKIE['current_user']['data']['groupID'];
   if (isset($_COOKIE['current_user']['data']['mobileAccess']))
      $GLOBALS['current_user']['data']['mobileAccess'] = $_COOKIE['current_user']['data']['mobileAccess'];
   $GLOBALS['current_user']['data']['userID'] = $_COOKIE['current_user']['data']['userID'];
   $GLOBALS['current_user']['data']['username'] = $_COOKIE['current_user']['data']['username'];
}
*/
$header = "Expires: " . gmdate("D, d M Y H:i:s", time() + 3) . " GMT".
          "Cache-Control: max-age=5";
header($header);

// Update session last access time only after more than 8 minutes to reduce access to master db 
// from remote sites
/*
if (isset($user_session['last_access_time']))
{
   $datediff=strtotime("now")-(strtotime($user_session['last_access_time']));
   if (abs($datediff)>480)
      $activityGrantor->updateActivityTime();
}

if (!isset($activity))
{
   $file_path=explode("/",$_SERVER['SCRIPT_FILENAME']);
   $activity=explode(".",$file_path[count($file_path)-1]);

   $activityGrantor->authorizeActivity($activity[0]);
}
else
   $activityGrantor->authorizeActivity($activity[0],0,$activity[1]);
*/
if ( (!isset($ajax_call)) || 
     ((isset($ajax_call)) && ($ajax_call!=1)) )
{
//require_once(COMMON_INC_DIR."gui.api.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML>

<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
<link href="https://synergis.alucio.net.id/css/font-awesome/css/all.css" rel="stylesheet" type="text/css" />
<script src="https://synergis.alucio.net.id/js/jquery.min.js"></script>
<script src="https://synergis.alucio.net.id/js/popper.min.js"></script>
</HEAD>
<?php
}
?>

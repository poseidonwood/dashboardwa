<?php
include_once("../configuration.inc");
include_once("../includes/koneksi.php");
include_once("../includes/function.php");
$url_example = MESSAGING_WEB_IMAGES;

$q = getContacts();
while ($row = mysqli_fetch_assoc($q)) {
  $row['remoteJid'] = $row['rJid'];
  if (preg_match("/g\.us/", $row['remoteJid']))
    $row['remoteJid'] = explode("|", $row['remoteJid'])[0];

  // $last = getLastMsg($row['remoteJid']);
  $row['nomor'] = explode("@", $row['remoteJid'])[0];

  $profile_data = getContactProfile($row['remoteJid']);

  if ($profile_data['profile_picture_path'] != "" or $profile_data['profile_picture_path'] != "undefined") {
    if ($profile_data['profile_picture_path'] == "") {
      $profile_pict_path1 = "../img/empty1.png";
    } else {
      $profile_pict_path2 = $url_example . "whatsapp/profile/" . $profile_data['profile_picture_path'];
      $validate1  = validateUrl($profile_pict_path2);
      if ($validate1 == false) {
        $profile_pict_path1 = "../img/empty1.png";
      } else {
        $profile_pict_path1 = $profile_pict_path2;
      }
      // $profile_pict_path1 = $profile_pict_path2;
    }
    $profile_pict_path = $profile_pict_path1;
  } else {
    $profile_pict_path = "../img/empty1.png";
  }

  $n = "";
  if ($profile_data['name'] != "") {
    $n = $profile_data['name'] . "<br />";
  }

?>
  <li class="chats-item">
    <div class="chats-item-button js-chat-button chatdiv" role="button" tabindex="0" data-shortjid="<?php
                                                                                                    if (preg_match("/c\.us/", $row['remoteJid']))
                                                                                                      echo $row['nomor'];
                                                                                                    else
                                                                                                      echo str_replace("@", "_", $row['remoteJid']);
                                                                                                    ?>" data-nomor="<?= $row['remoteJid'] ?>" data-name="<?= $n ?><?php
                                                                                                                                                                  if (!preg_match("/g\.us/", $row['remoteJid'])) echo $row['nomor']; ?>">
      <img class="profile-image" id="<?= $row['nomor'] ?>_pp" src="<?php echo $profile_pict_path; ?>" alt="">
      <header class="chats-item-header">
        <h3 class="chats-item-title"><?= $n ?><?php
                                              if (!preg_match("/g\.us/", $row['remoteJid'])) echo $row['nomor'];
                                              ?></h3>
        <!-- <time class="chats-item-time tanggal-terakhir-<?= $row['nomor'] ?>"><?= $last['messageTimestamp'] ?></time> -->
      </header>
      <div class="chats-item-content">
        <!-- <p class="chats-item-last pesan-terakhir-<?= $row['nomor'] ?>"><?= $last['message'] ?></p> -->
        <p class="chats-item-last pesan-terakhir><?= $row['nomor'] ?>"></p>
        <ul class="chats-item-info">
          <li class="chats-item-info-item"><span class="unread-messsages"></span></li>
        </ul>
      </div>
    </div>
  </li>
<?php
}
?>
<script>
  $('.chatdiv').click(function(data) {
    let jid = $(this).data("nomor");
    let nomor = $(this).data("shortjid");
    let name = $(this).data("name");
    $(".pesan-container").empty();
    $(".nomor").empty();
    $(".nomor").val(nomor);
    $(".nama-container").html(name);
    $("#common-header-profile-image").attr('src', $("#" + nomor + "_pp").attr('src'));
    $(".main-info-image").attr('src', $("#" + nomor + "_pp").attr('src'));
    $.get("get_chat.php?nomor=" + jid, function(data) {
      r = JSON.parse(data);

      jQuery.each(r, function(i, val) {
        let from_me = "";
        //console.log(val.fromMe);
        if (val.fromMe == false) {
          from_me = "is-other";
        } else {
          from_me = "is-you";
        }
        let chat = "<li class='common-message " + from_me + "'>" +
          "<p class='common-message-content'>" + val.message + "</p>" +
          "<time datetime>" + val.tanggal + "</time>" +
          "<span class='status'>" + val.ack + "</span>" +
          "</li>";
        $("#message-box").show();
        $("#header-webconsole").show();
        $(".pesan-container").append(chat);
        updateScroll();
      });
      localStorage.setItem('nomor', nomor);
    });
  });
</script>
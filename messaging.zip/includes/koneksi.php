<?php
if (preg_match("/:/", DB_HOSTPORT)) {
   $db_data = explode(":", DB_HOSTPORT);
   $db_host = $db_data[0];
   $db_port = $db_data[1];
} else {
   $db_host = DB_HOSTPORT;
   $db_port = "3306";
}

$username = DB_USERNAME;
$password = DB_PASSWORD;
$db = DB_PREFIX . "whatsapp";
$koneksi = mysqli_connect($db_host, $username, $password, $db, $db_port) or die("GAGAL");
mysqli_set_charset($koneksi, "utf8mb4");
$base_url = MESSAGING_WEB_ROOT;
date_default_timezone_set('Asia/Jakarta');
// $data = array(
//    'host' => $db_host,
//    'username' => $username,
//    'password' => $password,
//    'db' => $db,
//    'dbport' => $db_port,
// );
// echo json_encode($data);
